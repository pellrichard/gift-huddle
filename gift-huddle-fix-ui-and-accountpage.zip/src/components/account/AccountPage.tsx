"use client";
import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import Button from "@/src/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Input } from "@/src/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/src/components/ui/avatar";
import { Badge } from "@/src/components/ui/badge";

export default function AccountPage() {
  const [name, setName] = useState("Jamie Lee");
  const stats = useMemo(() => ({ upcoming: 3, ideas: 7, gifts: 2 }), []);
  return (
    <div className="max-w-5xl mx-auto px-6 py-10 space-y-8">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarImage alt="User avatar" src="/avatar.png" />
            <AvatarFallback>JL</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-semibold">My Account</h1>
            <p className="text-sm text-gray-500">Manage your details and track occasions.</p>
          </div>
        </div>
        <Button>Save changes</Button>
      </header>
      <div className="grid md:grid-cols-3 gap-4">
        <Card><CardHeader><CardTitle>Upcoming</CardTitle></CardHeader><CardContent className="text-2xl">{stats.upcoming}</CardContent></Card>
        <Card><CardHeader><CardTitle>Ideas</CardTitle></CardHeader><CardContent className="text-2xl">{stats.ideas}</CardContent></Card>
        <Card><CardHeader><CardTitle>Gifts Planned</CardTitle></CardHeader><CardContent className="text-2xl">{stats.gifts}</CardContent></Card>
      </div>
      <Card>
        <CardHeader><CardTitle>Profile</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <label className="block text-sm font-medium">Name</label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
          <div className="flex items-center gap-2">
            <Badge>Early Access</Badge>
            <Badge>Beta</Badge>
          </div>
        </CardContent>
      </Card>
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2 }}>
        <p className="text-xs text-gray-500">Tip: Invite friends to collaborate on gift lists from the Events page.</p>
      </motion.div>
    </div>
  );
}
