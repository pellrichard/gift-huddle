// Tailwind v4 + Next 15
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
