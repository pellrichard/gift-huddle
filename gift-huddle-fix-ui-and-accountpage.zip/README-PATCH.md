# Patch: add minimal UI components and fix AccountPage

This patch adds lightweight `src/components/ui/*` components (button, card, input, avatar, badge)
and updates `src/components/account/AccountPage.tsx` to be a Client Component and avoid missing deps.

## How to apply

From your repo root:
```bash
unzip -o gift-huddle-fix-ui-and-accountpage.zip -d .
git checkout -b fix/ui-shims-accountpage
git add src/components/ui src/components/account/AccountPage.tsx src/lib/utils.ts
git commit -m "fix: add minimal ui shims and patch AccountPage ('use client')"
git push -u origin fix/ui-shims-accountpage
```

Then open a PR from `fix/ui-shims-accountpage` to your integration branch.

## Optional
If you want to keep lucide icons later:
```bash
npm i lucide-react
```
and re-introduce icon imports.
